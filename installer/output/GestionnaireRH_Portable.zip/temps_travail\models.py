from django.db import models
from django.core.validators import MinValueValidator
from employes.models import Employe
from core.models import Entreprise


class JourFerie(models.Model):
    """Jours fériés"""
    TYPES = (
        ('national', 'National'),
        ('religieux', 'Religieux'),
        ('local', 'Local'),
    )
    
    entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE, related_name='jours_feries', null=True, blank=True)
    libelle = models.CharField(max_length=100)
    date_jour_ferie = models.DateField()
    annee = models.IntegerField()
    type_ferie = models.CharField(max_length=50, choices=TYPES)
    recurrent = models.BooleanField(default=False)
    jour_recuperation = models.DateField(blank=True, null=True)
    observations = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'calendrier_jours_feries'
        verbose_name = 'Jour férié'
        verbose_name_plural = 'Jours fériés'
        ordering = ['date_jour_ferie']
    
    def __str__(self):
        return f"{self.libelle} - {self.date_jour_ferie}"


class Conge(models.Model):
    """Congés des employés - Conformes au Code du Travail guinéen"""
    TYPES = (
        # Congés légaux
        ('annuel', 'Congé annuel (2,5j/mois)'),
        ('anciennete', 'Congé d\'ancienneté'),
        ('maladie', 'Congé maladie'),
        ('maternite', 'Congé maternité (14 semaines)'),
        ('paternite', 'Congé paternité (3 jours)'),
        # Congés exceptionnels (événements familiaux)
        ('mariage', 'Congé mariage (4 jours)'),
        ('naissance', 'Congé naissance (3 jours)'),
        ('deces_conjoint', 'Décès conjoint/enfant (5 jours)'),
        ('deces_parent', 'Décès parent/beau-parent (3 jours)'),
        ('deces_autre', 'Décès autre famille (1 jour)'),
        # Autres congés
        ('formation', 'Congé formation'),
        ('examen', 'Congé pour examen'),
        ('sans_solde', 'Congé sans solde'),
        ('recuperation', 'Récupération'),
    )
    
    STATUTS = (
        ('en_attente', 'En attente'),
        ('approuve', 'Approuvé'),
        ('rejete', 'Rejeté'),
        ('annule', 'Annulé'),
    )
    
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='conges')
    type_conge = models.CharField(max_length=50, choices=TYPES)
    date_debut = models.DateField()
    date_fin = models.DateField()
    nombre_jours = models.IntegerField(validators=[MinValueValidator(1)])
    annee_reference = models.IntegerField(blank=True, null=True)
    motif = models.TextField(blank=True, null=True)
    justificatif = models.FileField(upload_to='conges/', blank=True, null=True)
    statut_demande = models.CharField(max_length=20, choices=STATUTS, default='en_attente')
    date_demande = models.DateField(auto_now_add=True)
    approbateur = models.ForeignKey(Employe, on_delete=models.SET_NULL, null=True, related_name='conges_approuves')
    date_approbation = models.DateField(blank=True, null=True)
    commentaire_approbateur = models.TextField(blank=True, null=True)
    remplacant = models.ForeignKey(Employe, on_delete=models.SET_NULL, null=True, blank=True, related_name='remplacements')
    
    class Meta:
        db_table = 'conges'
        verbose_name = 'Congé'
        verbose_name_plural = 'Congés'
        ordering = ['-date_debut']
    
    def __str__(self):
        return f"{self.employe.nom_complet} - {self.get_type_conge_display()} ({self.date_debut})"


class SoldeConge(models.Model):
    """Soldes de congés"""
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='soldes_conges')
    annee = models.IntegerField()
    conges_acquis = models.DecimalField(max_digits=5, decimal_places=2, default=26.00)
    conges_pris = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    conges_restants = models.DecimalField(max_digits=5, decimal_places=2, default=26.00)
    conges_reports = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    date_mise_a_jour = models.DateField(auto_now=True)
    
    class Meta:
        db_table = 'soldes_conges'
        verbose_name = 'Solde de congé'
        verbose_name_plural = 'Soldes de congés'
        unique_together = ['employe', 'annee']
        ordering = ['-annee']
    
    def __str__(self):
        return f"{self.employe.nom_complet} - {self.annee} ({self.conges_restants} jours)"


class Pointage(models.Model):
    """Pointages quotidiens"""
    STATUTS = (
        ('present', 'Présent'),
        ('absent', 'Absent'),
        ('retard', 'Retard'),
        ('absence_justifiee', 'Absence justifiée'),
    )
    
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='pointages')
    date_pointage = models.DateField()
    heure_entree = models.TimeField(blank=True, null=True)
    heure_sortie = models.TimeField(blank=True, null=True)
    heures_travaillees = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    heures_supplementaires = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, default=0)
    statut_pointage = models.CharField(max_length=20, choices=STATUTS, default='present')
    motif_absence = models.CharField(max_length=50, blank=True, null=True)
    justificatif = models.FileField(upload_to='pointages/', blank=True, null=True)
    valide = models.BooleanField(default=False)
    observations = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'pointages'
        verbose_name = 'Pointage'
        verbose_name_plural = 'Pointages'
        unique_together = ['employe', 'date_pointage']
        ordering = ['-date_pointage']
    
    def __str__(self):
        return f"{self.employe.nom_complet} - {self.date_pointage}"


class Absence(models.Model):
    """Absences des employés"""
    TYPES = (
        ('maladie', 'Maladie'),
        ('accident_travail', 'Accident de travail'),
        ('absence_injustifiee', 'Absence injustifiée'),
        ('permission', 'Permission'),
    )
    
    IMPACTS = (
        ('paye', 'Payé'),
        ('non_paye', 'Non payé'),
        ('partiellement_paye', 'Partiellement payé'),
    )
    
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='absences')
    date_absence = models.DateField()
    type_absence = models.CharField(max_length=50, choices=TYPES)
    duree_jours = models.DecimalField(max_digits=5, decimal_places=2, default=1)
    justifie = models.BooleanField(default=False)
    justificatif = models.FileField(upload_to='absences/', blank=True, null=True)
    impact_paie = models.CharField(max_length=20, choices=IMPACTS, default='paye')
    taux_maintien_salaire = models.DecimalField(max_digits=5, decimal_places=2, default=100.00)
    observations = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'absences'
        verbose_name = 'Absence'
        verbose_name_plural = 'Absences'
        ordering = ['-date_absence']
    
    def __str__(self):
        return f"{self.employe.nom} {self.employe.prenoms} - {self.get_type_absence_display()} ({self.date_absence})"


class ArretTravail(models.Model):
    """Arrêts de travail (maladie, accident)"""
    TYPES = (
        ('maladie', 'Maladie'),
        ('accident_travail', 'Accident de travail'),
        ('maladie_professionnelle', 'Maladie professionnelle'),
    )
    
    ORGANISMES = (
        ('inam', 'INAM'),
        ('employeur', 'Employeur'),
        ('mixte', 'Mixte'),
    )
    
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='arrets_travail')
    type_arret = models.CharField(max_length=50, choices=TYPES)
    date_debut = models.DateField()
    date_fin = models.DateField(blank=True, null=True)
    duree_jours = models.IntegerField(blank=True, null=True)
    medecin_prescripteur = models.CharField(max_length=100, blank=True)
    numero_certificat = models.CharField(max_length=50, blank=True)
    organisme_payeur = models.CharField(max_length=50, choices=ORGANISMES, default='inam')
    taux_indemnisation = models.DecimalField(max_digits=5, decimal_places=2, default=100.00, help_text="% du salaire")
    montant_indemnites = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    prolongation = models.BooleanField(default=False)
    arret_initial = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='prolongations')
    fichier_certificat = models.FileField(upload_to='arrets_travail/', blank=True, null=True)
    observations = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'arrets_travail'
        verbose_name = 'Arrêt de travail'
        verbose_name_plural = 'Arrêts de travail'
        ordering = ['-date_debut']
    
    def __str__(self):
        return f"{self.employe.nom} {self.employe.prenoms} - {self.get_type_arret_display()} ({self.date_debut})"


class HoraireTravail(models.Model):
    """Horaires de travail"""
    TYPES = (
        ('normal', 'Normal'),
        ('equipe', 'Équipe'),
        ('nuit', 'Nuit'),
        ('flexible', 'Flexible'),
    )
    
    entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE, related_name='horaires_travail', null=True, blank=True)
    code_horaire = models.CharField(max_length=20, unique=True)
    libelle_horaire = models.CharField(max_length=100)
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    heure_pause_debut = models.TimeField(blank=True, null=True)
    heure_pause_fin = models.TimeField(blank=True, null=True)
    heures_jour = models.DecimalField(max_digits=5, decimal_places=2, default=8.00)
    type_horaire = models.CharField(max_length=20, choices=TYPES, default='normal')
    actif = models.BooleanField(default=True)
    
    class Meta:
        db_table = 'horaires_travail'
        verbose_name = 'Horaire de travail'
        verbose_name_plural = 'Horaires de travail'
        ordering = ['code_horaire']
    
    def __str__(self):
        return f"{self.code_horaire} - {self.libelle_horaire} ({self.heure_debut}-{self.heure_fin})"


class AffectationHoraire(models.Model):
    """Affectation des horaires aux employés"""
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='affectations_horaires')
    horaire = models.ForeignKey(HoraireTravail, on_delete=models.CASCADE, related_name='affectations')
    date_debut = models.DateField()
    date_fin = models.DateField(blank=True, null=True)
    actif = models.BooleanField(default=True)
    
    class Meta:
        db_table = 'affectation_horaires'
        verbose_name = 'Affectation horaire'
        verbose_name_plural = 'Affectations horaires'
        ordering = ['-date_debut']
    
    def __str__(self):
        return f"{self.employe.nom} {self.employe.prenoms} - {self.horaire.libelle_horaire}"


# ============= RÉGLEMENTATION TEMPS DE TRAVAIL (Code du Travail guinéen) =============

class ReglementationTemps(models.Model):
    """Paramètres de réglementation du temps de travail"""
    entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE, related_name='reglementations_temps', null=True, blank=True)
    annee = models.IntegerField()
    
    # Durée légale du travail
    duree_hebdo_legale = models.DecimalField(max_digits=4, decimal_places=2, default=40.00, help_text="Durée hebdomadaire légale (40h en Guinée)")
    duree_journaliere_max = models.DecimalField(max_digits=4, decimal_places=2, default=10.00, help_text="Durée journalière maximale")
    
    # Heures supplémentaires
    taux_hs_jour_25 = models.DecimalField(max_digits=5, decimal_places=2, default=125.00, help_text="Taux HS jour (1-8h): 125%")
    taux_hs_jour_50 = models.DecimalField(max_digits=5, decimal_places=2, default=150.00, help_text="Taux HS jour (>8h): 150%")
    taux_hs_nuit = models.DecimalField(max_digits=5, decimal_places=2, default=150.00, help_text="Taux HS nuit: 150%")
    taux_hs_dimanche = models.DecimalField(max_digits=5, decimal_places=2, default=175.00, help_text="Taux HS dimanche/férié: 175%")
    taux_hs_nuit_dimanche = models.DecimalField(max_digits=5, decimal_places=2, default=200.00, help_text="Taux HS nuit dimanche: 200%")
    
    # Travail de nuit
    heure_debut_nuit = models.TimeField(default='21:00', help_text="Début période de nuit")
    heure_fin_nuit = models.TimeField(default='05:00', help_text="Fin période de nuit")
    majoration_nuit = models.DecimalField(max_digits=5, decimal_places=2, default=25.00, help_text="Majoration travail de nuit: 25%")
    
    # Repos
    repos_hebdo_jour = models.CharField(max_length=20, default='dimanche', help_text="Jour de repos hebdomadaire")
    duree_repos_hebdo_min = models.IntegerField(default=24, help_text="Durée minimale repos hebdo (heures)")
    
    # Congés
    jours_conges_annuels = models.DecimalField(max_digits=4, decimal_places=2, default=26.00, help_text="Jours de congés annuels (2,5j/mois)")
    jours_conges_anciennete_5ans = models.IntegerField(default=1, help_text="Jours supplémentaires après 5 ans")
    jours_conges_anciennete_10ans = models.IntegerField(default=2, help_text="Jours supplémentaires après 10 ans")
    jours_conges_anciennete_15ans = models.IntegerField(default=3, help_text="Jours supplémentaires après 15 ans")
    jours_conges_anciennete_20ans = models.IntegerField(default=4, help_text="Jours supplémentaires après 20 ans")
    
    actif = models.BooleanField(default=True)
    
    class Meta:
        db_table = 'reglementation_temps'
        verbose_name = 'Réglementation temps de travail'
        verbose_name_plural = 'Réglementations temps de travail'
        unique_together = ['entreprise', 'annee']
    
    def __str__(self):
        return f"Réglementation {self.annee}"


class DroitConge(models.Model):
    """Droits aux congés par employé et par année"""
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='droits_conges')
    annee = models.IntegerField()
    periode_reference_debut = models.DateField()
    periode_reference_fin = models.DateField()
    
    # Jours acquis
    jours_acquis_base = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Jours acquis (base 2,5j/mois)")
    jours_acquis_anciennete = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Jours supplémentaires ancienneté")
    jours_reportes = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Jours reportés année précédente")
    jours_exceptionnels = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Jours exceptionnels accordés")
    
    # Jours utilisés
    jours_pris = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    jours_planifies = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    
    # Solde
    solde_disponible = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    
    # Indemnité compensatrice (en cas de départ)
    indemnite_conge = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    
    date_mise_a_jour = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'droits_conges'
        verbose_name = 'Droit aux congés'
        verbose_name_plural = 'Droits aux congés'
        unique_together = ['employe', 'annee']
    
    def __str__(self):
        return f"{self.employe.nom_complet} - {self.annee}: {self.solde_disponible} jours"
    
    def calculer_solde(self):
        """Calculer le solde disponible"""
        total_acquis = (
            self.jours_acquis_base + 
            self.jours_acquis_anciennete + 
            self.jours_reportes + 
            self.jours_exceptionnels
        )
        self.solde_disponible = total_acquis - self.jours_pris - self.jours_planifies
        return self.solde_disponible
