from django.apps import AppConfig


class FormationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'formation'
    verbose_name = 'Formation'
