"""
Vues pour la conformité inspection du travail
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
from django.utils import timezone
from datetime import date, timedelta

from core.models import RegistreObligatoire, VisiteInspection
from core.views import log_activity


@login_required
def inspection_dashboard(request):
    """Tableau de bord conformité inspection du travail"""
    entreprise = request.user.entreprise
    
    # Registres obligatoires
    registres = RegistreObligatoire.objects.filter(
        entreprise=entreprise
    )
    
    registres_a_jour = registres.filter(conforme=True).count()
    registres_total = registres.count()
    
    # Dernières visites
    visites = VisiteInspection.objects.filter(
        entreprise=entreprise
    ).order_by('-date_visite')[:5]
    
    # Dernier rapport (simplifié - pas de modèle RapportConformite)
    dernier_rapport = None
    
    # Score de conformité
    if registres_total > 0:
        score_conformite = int((registres_a_jour / registres_total) * 100)
    else:
        score_conformite = 0
    
    return render(request, 'core/inspection/dashboard.html', {
        'registres': registres,
        'registres_a_jour': registres_a_jour,
        'registres_total': registres_total,
        'score_conformite': score_conformite,
        'visites': visites,
        'dernier_rapport': dernier_rapport,
    })


@login_required
def registres_liste(request):
    """Liste des registres obligatoires"""
    registres = RegistreObligatoire.objects.filter(
        entreprise=request.user.entreprise
    ).order_by('type_registre')
    
    return render(request, 'core/inspection/registres_liste.html', {
        'registres': registres,
    })


@login_required
def registre_ajouter(request):
    """Ajouter un registre obligatoire"""
    if request.method == 'POST':
        registre = RegistreObligatoire.objects.create(
            entreprise=request.user.entreprise,
            type_registre=request.POST.get('type_registre', 'personnel'),
            reference=request.POST.get('reference', ''),
            date_ouverture=request.POST.get('date_ouverture') or None,
            derniere_mise_a_jour=request.POST.get('derniere_mise_a_jour') or None,
            responsable=request.POST.get('responsable', ''),
            emplacement=request.POST.get('emplacement', ''),
            conforme=request.POST.get('conforme') == 'on',
            observations=request.POST.get('observations', ''),
        )
        
        log_activity(request, f"Ajout registre {registre.get_type_registre_display()}", 'core')
        messages.success(request, 'Registre ajouté')
        return redirect('core:registres_liste')
    
    return render(request, 'core/inspection/registre_form.html', {})


@login_required
def registre_modifier(request, pk):
    """Modifier un registre"""
    registre = get_object_or_404(
        RegistreObligatoire,
        pk=pk,
        entreprise=request.user.entreprise
    )
    
    if request.method == 'POST':
        registre.type_registre = request.POST.get('type_registre', 'personnel')
        registre.reference = request.POST.get('reference', '')
        registre.date_ouverture = request.POST.get('date_ouverture') or None
        registre.derniere_mise_a_jour = request.POST.get('derniere_mise_a_jour') or None
        registre.responsable = request.POST.get('responsable', '')
        registre.emplacement = request.POST.get('emplacement', '')
        registre.conforme = request.POST.get('conforme') == 'on'
        registre.observations = request.POST.get('observations', '')
        registre.save()
        
        log_activity(request, f"Modification registre {registre.reference}", 'core')
        messages.success(request, 'Registre modifié')
        return redirect('core:registres_liste')
    
    return render(request, 'core/inspection/registre_form.html', {
        'registre': registre,
        'modification': True,
    })


@login_required
def visites_liste(request):
    """Liste des visites d'inspection"""
    visites = VisiteInspection.objects.filter(
        entreprise=request.user.entreprise
    ).order_by('-date_visite')
    
    return render(request, 'core/inspection/visites_liste.html', {
        'visites': visites,
    })


@login_required
def visite_ajouter(request):
    """Enregistrer une visite d'inspection"""
    if request.method == 'POST':
        visite = VisiteInspection.objects.create(
            entreprise=request.user.entreprise,
            date_visite=request.POST.get('date_visite') or date.today(),
            type_visite=request.POST.get('type_visite', 'routine'),
            inspecteur=request.POST.get('inspecteur', ''),
            motif=request.POST.get('motif', ''),
            observations=request.POST.get('observations', ''),
            actions_requises=request.POST.get('actions_requises', ''),
            date_limite_actions=request.POST.get('date_limite_actions') or None,
            statut=request.POST.get('statut', 'en_cours'),
        )
        
        log_activity(request, f"Enregistrement visite inspection {visite.date_visite}", 'core')
        messages.success(request, 'Visite enregistrée')
        return redirect('core:visites_liste')
    
    return render(request, 'core/inspection/visite_form.html', {})


@login_required
def visite_detail(request, pk):
    """Détail d'une visite d'inspection"""
    visite = get_object_or_404(
        VisiteInspection,
        pk=pk,
        entreprise=request.user.entreprise
    )
    
    return render(request, 'core/inspection/visite_detail.html', {
        'visite': visite,
    })


@login_required
def checklist_conformite(request):
    """Checklist de conformité inspection du travail"""
    entreprise = request.user.entreprise
    
    # Liste des éléments à vérifier
    checklist = [
        {
            'categorie': 'Registres obligatoires',
            'items': [
                {'code': 'REG_PERSONNEL', 'libelle': 'Registre du personnel à jour', 'obligatoire': True},
                {'code': 'REG_PAIE', 'libelle': 'Registre de paie mensuel', 'obligatoire': True},
                {'code': 'REG_CONGES', 'libelle': 'Registre des congés payés', 'obligatoire': True},
                {'code': 'REG_ACCIDENTS', 'libelle': 'Registre des accidents du travail', 'obligatoire': True},
                {'code': 'REG_DELEGUES', 'libelle': 'Registre des délégués du personnel', 'obligatoire': False},
            ]
        },
        {
            'categorie': 'Affichages obligatoires',
            'items': [
                {'code': 'AFF_HORAIRES', 'libelle': 'Horaires de travail affichés', 'obligatoire': True},
                {'code': 'AFF_REGLEMENT', 'libelle': 'Règlement intérieur affiché', 'obligatoire': True},
                {'code': 'AFF_SECURITE', 'libelle': 'Consignes de sécurité affichées', 'obligatoire': True},
                {'code': 'AFF_INSPECTION', 'libelle': 'Coordonnées inspection du travail', 'obligatoire': True},
                {'code': 'AFF_MEDECINE', 'libelle': 'Coordonnées médecine du travail', 'obligatoire': True},
            ]
        },
        {
            'categorie': 'Documents contrats',
            'items': [
                {'code': 'DOC_CONTRATS', 'libelle': 'Contrats de travail signés', 'obligatoire': True},
                {'code': 'DOC_BULLETINS', 'libelle': 'Bulletins de paie remis', 'obligatoire': True},
                {'code': 'DOC_ATTESTATIONS', 'libelle': 'Attestations CNSS à jour', 'obligatoire': True},
            ]
        },
        {
            'categorie': 'Hygiène et sécurité',
            'items': [
                {'code': 'SEC_EXTINCTEURS', 'libelle': 'Extincteurs vérifiés', 'obligatoire': True},
                {'code': 'SEC_TROUSSE', 'libelle': 'Trousse de premiers secours', 'obligatoire': True},
                {'code': 'SEC_EQUIPEMENTS', 'libelle': 'Équipements de protection fournis', 'obligatoire': False},
                {'code': 'SEC_FORMATION', 'libelle': 'Formation sécurité dispensée', 'obligatoire': False},
            ]
        },
    ]
    
    # Vérifier l'état actuel
    registres = {r.type_registre: r.conforme for r in RegistreObligatoire.objects.filter(entreprise=entreprise)}
    
    total_items = 0
    items_conformes = 0
    
    for cat in checklist:
        for item in cat['items']:
            total_items += 1
            # Vérifier si conforme (logique simplifiée)
            if item['code'].startswith('REG_'):
                reg_type = item['code'].replace('REG_', '').lower()
                item['conforme'] = registres.get(reg_type, False)
            else:
                item['conforme'] = False  # À implémenter selon les besoins
            
            if item['conforme']:
                items_conformes += 1
    
    score = int((items_conformes / total_items) * 100) if total_items > 0 else 0
    
    return render(request, 'core/inspection/checklist.html', {
        'checklist': checklist,
        'score': score,
        'items_conformes': items_conformes,
        'total_items': total_items,
    })


@login_required
def generer_rapport_conformite(request):
    """Générer un rapport de conformité (affichage simplifié)"""
    entreprise = request.user.entreprise
    
    # Calculer le score
    registres = RegistreObligatoire.objects.filter(entreprise=entreprise)
    registres_conformes = registres.filter(conforme=True).count()
    total = registres.count()
    score = int((registres_conformes / total) * 100) if total > 0 else 0
    
    if request.method == 'POST':
        log_activity(request, f"Génération rapport conformité - Score {score}%", 'core')
        messages.success(request, f'Rapport généré - Score: {score}%')
        return redirect('core:inspection_dashboard')
    
    return render(request, 'core/inspection/generer_rapport.html', {
        'score': score,
        'registres_conformes': registres_conformes,
        'registres_total': total,
    })
